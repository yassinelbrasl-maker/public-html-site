<?php
// TEST v3 — Simule exactement createProjectNasFolder
require_once __DIR__ . '/../config/middleware.php';
header('Content-Type: text/html; charset=utf-8');

echo '<html><head><style>
body{font-family:monospace;background:#1a1a1a;color:#ccc;padding:20px}
.ok{color:#4caf50} .err{color:#f44336} .warn{color:#ff9800}
code{background:#2a2a2a;padding:2px 6px;border-radius:3px}
.step{background:#222;border:1px solid #444;padding:12px;margin:8px 0;border-radius:6px}
</style></head><body>';
echo '<h2>Test v3 — Simulation createProjectNasFolder</h2>';

// ── Lire config exactement comme getNasCfg() ──
function readCfg($key, $default = '') {
    $db = getDB();
    try {
        $stmt = $db->prepare('SELECT setting_value FROM CA_settings WHERE setting_key = ? LIMIT 1');
        $stmt->execute(array($key));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $decoded = json_decode($row['setting_value'], true);
            return ($decoded !== null) ? $decoded : $row['setting_value'];
        }
    } catch (Exception $e) {
        echo '<p class="err">DB Error pour ' . $key . ' : ' . $e->getMessage() . '</p>';
    }
    return $default;
}

$local      = readCfg('cortoba_nas_local', '');
$publicIp   = readCfg('cortoba_nas_public_ip', '');
$webdavPort = readCfg('cortoba_nas_webdav_port', '5005');
$webdavBase = readCfg('cortoba_nas_webdav', '');
$user       = readCfg('cortoba_nas_user', 'admin');
$pass       = readCfg('cortoba_nas_pass', '');

echo '<div class="step"><strong>1. Config lue depuis DB :</strong><br>';
echo 'local = <code>' . htmlspecialchars($local) . '</code><br>';
echo 'publicIp = <code>' . htmlspecialchars($publicIp) . '</code><br>';
echo 'webdavPort = <code>' . htmlspecialchars($webdavPort) . '</code><br>';
echo 'webdavBase (DB) = <code>' . htmlspecialchars($webdavBase ?: '(vide)') . '</code><br>';
echo 'user = <code>' . htmlspecialchars($user) . '</code><br>';
echo 'pass = <code>' . ($pass ? '••••••' : '<span class="err">(VIDE)</span>') . '</code><br>';
echo '</div>';

// ── Extraction webdavBase depuis UNC (exactement comme le code PHP) ──
if (!$webdavBase && $local && preg_match('/^[\\\\\/]{2}[^\\\\\/]+[\\\\\/](.+)$/', $local, $mx)) {
    $webdavBase = str_replace('\\', '/', trim($mx[1], '\\/'));
    echo '<div class="step"><strong>2. webdavBase extrait du UNC :</strong> <code>' . htmlspecialchars($webdavBase) . '</code></div>';
} else {
    echo '<div class="step"><strong>2. webdavBase :</strong> <code>' . htmlspecialchars($webdavBase ?: '(toujours vide!)') . '</code>';
    if (!$webdavBase) echo ' <span class="err">← PROBLÈME : aucun chemin WebDAV !</span>';
    echo '</div>';
}

// ── Déterminer l'IP ──
$ip = '';
if ($publicIp) {
    $ip = trim($publicIp);
    echo '<div class="step"><strong>3. IP utilisée (publique) :</strong> <code>' . htmlspecialchars($ip) . '</code></div>';
} elseif ($local) {
    if (preg_match('/^[\\\\\/]{2}([^\\\\\/]+)/', $local, $m)) {
        $ip = $m[1];
    } else {
        $ip = trim($local);
    }
    echo '<div class="step"><strong>3. IP utilisée (locale) :</strong> <code>' . htmlspecialchars($ip) . '</code> <span class="warn">← IP locale, pas accessible depuis le serveur</span></div>';
}

if (!$ip || !$webdavPort) {
    echo '<p class="err">ARRÊT : ip ou port manquant</p></body></html>';
    exit;
}

// ── Construire l'URL de base ──
$base = rtrim('http://' . $ip . ':' . $webdavPort . ($webdavBase ? '/' . ltrim(str_replace('\\', '/', $webdavBase), '/') : ''), '/');
echo '<div class="step"><strong>4. URL de base WebDAV :</strong> <code>' . htmlspecialchars($base) . '</code></div>';

// ── Test avec un vrai code projet ──
$testCode   = 'TEST_' . date('His');
$testAnnee  = '2026';
$testClient = 'Test_Client';
$folderName = $testCode . '_' . $testClient;

$yearUrl    = $base . '/' . $testAnnee . '/';
$projectUrl = $yearUrl . rawurlencode($folderName) . '/';

echo '<div class="step"><strong>5. URLs générées :</strong><br>';
echo 'Année : <code>' . htmlspecialchars($yearUrl) . '</code><br>';
echo 'Projet : <code>' . htmlspecialchars($projectUrl) . '</code></div>';

// ── Test MKCOL année ──
echo '<div class="step"><strong>6. MKCOL dossier année :</strong> ';
$ch = curl_init($yearUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'MKCOL');
curl_setopt($ch, CURLOPT_USERPWD, $user . ':' . $pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
curl_exec($ch);
$c1 = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$e1 = curl_error($ch);
curl_close($ch);
if ($c1 == 201) echo '<span class="ok">201 Créé ✓</span>';
elseif ($c1 == 405) echo '<span class="ok">405 Existe déjà ✓</span>';
elseif ($c1 == 0) echo '<span class="err">Timeout — ' . htmlspecialchars($e1) . '</span>';
else echo '<span class="warn">HTTP ' . $c1 . ($e1 ? " — $e1" : '') . '</span>';
echo '</div>';

// ── Test MKCOL projet ──
echo '<div class="step"><strong>7. MKCOL dossier projet :</strong> ';
$ch2 = curl_init($projectUrl);
curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch2, CURLOPT_CUSTOMREQUEST, 'MKCOL');
curl_setopt($ch2, CURLOPT_USERPWD, $user . ':' . $pass);
curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch2, CURLOPT_CONNECTTIMEOUT, 3);
curl_setopt($ch2, CURLOPT_TIMEOUT, 5);
curl_exec($ch2);
$c2 = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
$e2 = curl_error($ch2);
curl_close($ch2);
if ($c2 == 201) echo '<span class="ok">201 DOSSIER CRÉÉ ✓</span>';
elseif ($c2 == 0) echo '<span class="err">Timeout — ' . htmlspecialchars($e2) . '</span>';
else echo '<span class="warn">HTTP ' . $c2 . ($e2 ? " — $e2" : '') . '</span>';
echo '</div>';

// ── Test PROPFIND template ──
$templateUrl = $yearUrl . rawurlencode('00-Dossier Type') . '/';
echo '<div class="step"><strong>8. PROPFIND template :</strong> <code>' . htmlspecialchars($templateUrl) . '</code><br>';
$ch3 = curl_init($templateUrl);
curl_setopt($ch3, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch3, CURLOPT_CUSTOMREQUEST, 'PROPFIND');
curl_setopt($ch3, CURLOPT_HTTPHEADER, array('Depth: 1', 'Content-Type: application/xml'));
curl_setopt($ch3, CURLOPT_USERPWD, $user . ':' . $pass);
curl_setopt($ch3, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch3, CURLOPT_CONNECTTIMEOUT, 3);
curl_setopt($ch3, CURLOPT_TIMEOUT, 5);
$propBody = curl_exec($ch3);
$c3 = curl_getinfo($ch3, CURLINFO_HTTP_CODE);
$e3 = curl_error($ch3);
curl_close($ch3);

if ($c3 == 207) {
    echo '<span class="ok">207 Multi-Status ✓</span><br>';
    // Parse folders
    $folders = array();
    $parentPath = rtrim(parse_url($templateUrl, PHP_URL_PATH), '/');
    if (preg_match_all('/<(?:D:|d:)?href>([^<]+)<\/(?:D:|d:)?href>/i', $propBody, $matches)) {
        for ($i = 0; $i < count($matches[1]); $i++) {
            $href = rtrim($matches[1][$i], '/');
            if ($href === $parentPath) continue;
            $parts = explode('/', $href);
            $name = rawurldecode(end($parts));
            if ($name && $name !== '.' && $name !== '..') {
                $folders[] = $name;
            }
        }
    }
    echo 'Sous-dossiers trouvés : <strong>' . count($folders) . '</strong><br>';
    foreach ($folders as $f) {
        echo '  📁 <code>' . htmlspecialchars($f) . '</code><br>';
    }

    // ── Test COPY des sous-dossiers ──
    if ($c2 == 201 && count($folders) > 0) {
        echo '<br><strong>9. COPY sous-dossiers dans le projet :</strong><br>';
        foreach ($folders as $sub) {
            $src  = $templateUrl . rawurlencode($sub) . '/';
            $dest = $projectUrl . rawurlencode($sub) . '/';
            $ch4 = curl_init($src);
            curl_setopt($ch4, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch4, CURLOPT_CUSTOMREQUEST, 'COPY');
            curl_setopt($ch4, CURLOPT_HTTPHEADER, array(
                'Destination: ' . $dest,
                'Depth: infinity',
                'Overwrite: F'
            ));
            curl_setopt($ch4, CURLOPT_USERPWD, $user . ':' . $pass);
            curl_setopt($ch4, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch4, CURLOPT_CONNECTTIMEOUT, 3);
            curl_setopt($ch4, CURLOPT_TIMEOUT, 15);
            curl_exec($ch4);
            $c4 = curl_getinfo($ch4, CURLINFO_HTTP_CODE);
            $e4 = curl_error($ch4);
            curl_close($ch4);
            $stat = ($c4 == 201 || $c4 == 204) ? '<span class="ok">' . $c4 . ' ✓</span>' : '<span class="err">' . $c4 . ($e4 ? " $e4" : '') . '</span>';
            echo '  📁 ' . htmlspecialchars($sub) . ' → ' . $stat . '<br>';
        }
    }
} elseif ($c3 == 0) {
    echo '<span class="err">Timeout — ' . htmlspecialchars($e3) . '</span>';
} elseif ($c3 == 404) {
    echo '<span class="err">404 — Dossier "00-Dossier Type" introuvable à cette URL</span>';
} else {
    echo '<span class="warn">HTTP ' . $c3 . ($e3 ? " — $e3" : '') . '</span>';
}
echo '</div>';

echo '<p style="color:#666;margin-top:20px">⚠️ Supprimer <code>api/test_nas.php</code> après usage</p>';
echo '</body></html>';
